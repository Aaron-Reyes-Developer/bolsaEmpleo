<?php
    require '../vendor/autoload.php';
    include('../conexion.php');
    
    
    ob_start();
    session_start();
    // error_reporting(0);


    // datos estudiantes
    $id_aspirante = $_REQUEST['id_aspirante'];
    $queryDatosAspirante = "call datosMainEstudiante('$id_aspirante')";
    $respuestaDatosAspirante = mysqli_query($conn, $queryDatosAspirante);
    $recorrerDatosAspirante = mysqli_fetch_array($respuestaDatosAspirante);
    while(mysqli_next_result($conn)){;}

    // datos de los cursos que ha realizado
    $queryCursos = "SELECT edu.nombre_institucion , edu.especializacion , edu.fecha_culminacion FROM educacion as edu LEFT JOIN curriculum as cu ON cu.id_curriculum = edu.fk_id_curriculum where edu.tipo = 'Curso' AND cu.fk_id_usuEstudiantes = '$id_aspirante' LIMIT 2";
    $respuestaCursos = mysqli_query($conn, $queryCursos);
    while(mysqli_next_result($conn)){;}
    
    
    // datos experiencia
    $queryDatosEducacion = "SELECT xp.nombre_empresa, xp.cargo, xp.tiempo_trabajo FROM experiencia as xp LEFT JOIN curriculum as  cu ON cu.id_curriculum = xp.fk_id_curriculum WHERE cu.fk_id_usuEstudiantes = '$id_aspirante' LIMIT 4";
    $respuestaDatosEducacion = mysqli_query($conn, $queryDatosEducacion);
    while(mysqli_next_result($conn)){;}

    // datos habilidades
    $queryHabilidades = "SELECT cono.nombre_conocimiento FROM conocimientos as cono LEFT JOIN curriculum as  cu ON cu.id_curriculum = cono.fk_id_curriculum WHERE cu.fk_id_usuEstudiantes = '$id_aspirante' LIMIT 8";
    $respuestaHabilidades = mysqli_query($conn, $queryHabilidades);
    while(mysqli_next_result($conn)){;}

    // datos idioma
    $id_curriculum = $recorrerDatosAspirante['id_curriculum'];
    $queryDatosIdioma = "SELECT idioma, nivel FROM idioma WHERE fk_id_curriculum = '$id_curriculum' LIMIT 2 ";
    $respuestaDatosIdioma = mysqli_query($conn, $queryDatosIdioma);
    while(mysqli_next_result($conn)){;}


    //funcion para consultar la edad del aspirante
    $queryEdad = "SELECT TIMESTAMPDIFF(YEAR,fecha_nacimiento ,CURDATE()) AS edad  FROM datos_estudiantes WHERE fk_id_usuEstudiantes= '$id_aspirante' ";
    $resultadoEdad = mysqli_query($conn, $queryEdad);
    $recorrerEdad = mysqli_fetch_array($resultadoEdad);
    while(mysqli_next_result($conn)){;}
?>

<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <link rel="stylesheet" href="estiloPdf.css">
    <title>Cv</title>
</head>



<body>

    <!-- relativo -->
    <div class='contenedorDecoracionPdf'>
        <img src='./escudoUnesum.png'>
        
    </div>

    <!-- avatar -->
    <div class="contenedorAvatar">
        <img src="data:Image/jpg;base64,<?php echo base64_encode($recorrerDatosAspirante['imagen_perfil'])?>" alt="">
    </div>

    <!-- titulo nombre -->
    <div class='contenedorTitulo'>
        <h1><?php echo $recorrerDatosAspirante['nombre'], " " ,$recorrerDatosAspirante['apellido']?></h1>
        <p><?php echo $recorrerDatosAspirante['especializacion']?> (<?php echo $recorrerEdad['edad']?> Años)</p>
        <span><?php echo $recorrerDatosAspirante['estado_trabajo']?></span><br>
    </div>

    <!-- descripcion -->
    <div class='contenedorDescripcionPersonal'>
        <span>
            <?php echo $recorrerDatosAspirante['detalle_curriculum']?>
        </span>
    </div>

    <hr class='lineaDivisora'>
    
    <!-- datos principales -->
    <div class='contenedorFlex'>

        <!-- contacto educacion cursos idiomas -->
        <div class='contactos-educacion-cursos-idiomas'>

            <!-- Contacto -->
            <div class='contenedorContacto'>

                <li class='tituloContacto titulos'>Contacto</li>

                <div class='informacionContacto info'>
                    <ul>
                        <li> <img src="./iconos/correo.png" style="width: 25px;"> <?php echo $recorrerDatosAspirante['correo']?></li>
                        <li> <img src="./iconos/llamada.jpg" style="width: 25px;"> <?php echo $recorrerDatosAspirante['numero_celular']?></li>
                        <li> <img src="./iconos/arroba.png" style="width: 25px;"> <?php echo $recorrerDatosAspirante['portafolio']?></li>
                        <li> <img src="./iconos/mapsNegro.png" style="width: 25px;"> <?php echo $recorrerDatosAspirante['lugar_donde_vive']?></li>
                    </ul>
                </div>

            </div>


            <!-- Educacion -->
            <div class='ContenedorEducacion'>

                <li class="titulos">Educación</li>
                
                <div class="datos">
                    <h4><?php echo $recorrerDatosAspirante['nombre_institucion']?></h4>
                    <span><?php echo $recorrerDatosAspirante['carrera_graduada']?></span><br>
                    <span><?php echo $recorrerDatosAspirante['tituloGraduado']?></span><br>
                    <span><?php echo $recorrerDatosAspirante['fecha_culminacion']?></span>
                </div>

            </div>


            <!-- Cursos / idiomas-->
            <div class='contenedorCursoIdiomas'>

                <li class="titulos">Cursos / Idiomas</li>
                
                <?php
                    while($recorrerCursos = mysqli_fetch_array($respuestaCursos)){
                        ?>
                            <div class="datos">
                                <h4><?php echo $recorrerCursos['especializacion'] ?></h4>
                                <span> <?php echo $recorrerCursos['nombre_institucion'] ?></span><br>
                                <span><?php echo $recorrerCursos['fecha_culminacion'] ?></span>
                            </div>
                        <?php
                    }


                    while($recorrerIdioma = mysqli_fetch_array($respuestaDatosIdioma)){
                        ?>
                            <div class="datos">
                                <h4>Idioma: <?php echo $recorrerIdioma['idioma']?></h4>
                                <span> Nivel: <?php echo $recorrerIdioma['nivel']?></span><br>
                                
                            </div>

                        <?php
                    }
                ?>
                
                
            <div>

        </div>


        <!-- experiencia y otros conocimientos-->
        <div class='experiencia'>

            <div class='contendorExperienciaLaboral'>

                <li class="tituloExperiencia titulos">Experiencia Laboral</li>

                <?php
                    while($recorrerExperiencia = mysqli_fetch_array($respuestaDatosEducacion)){
                        ?>
                            <div class="datos">
                                <h4><?php echo $recorrerExperiencia['cargo']?></h4>
                                <span>Empresa:  <?php echo $recorrerExperiencia['nombre_empresa'], " (" ,$recorrerExperiencia['tiempo_trabajo'] , ")"?></span><br>
                            </div>

                        <?php
                    }
                ?>
            </div>

            <!-- otros concimiento -->
            <div class='otrosConocimeientos contenedorConocimiento'>

                <div class='contendorExperienciaLaboral'>

                    <li class="tituloExperiencia titulos">Otros Conocimientos</li>

                    <div class="datos ">
                        <li class="parrafoOtrosConocimientos otroConocimientoParrafo"><?php echo $recorrerDatosAspirante['habilidades']?></li>
                    </div>

                    


                </div>

            </div>

            <!-- HABILIDADES -->
            <div class='otrosConocimeientos habilidades'>

                <div class='contendorExperienciaLaboral'>

                    <li class="tituloExperiencia titulos">Habilidades</li>
                    
                    <?php
                        while($recorrerHabilidades = mysqli_fetch_array($respuestaHabilidades)){
                            ?>
                                <div class="datos datosHabilidades">
                                    <li class="parrafoOtrosConocimientos"><?php echo $recorrerHabilidades['nombre_conocimiento']?></li>
                                </div>
                            <?php
                        }
                    
                    
                    ?>
                    
                </div>

            </div>
        </div>

        

    </div>

</body>
</html>
    
<?php
    $nombreAspirante = $recorrerDatosAspirante['nombre']." ".$recorrerDatosAspirante['apellido'];
    $nombrePdf = 'Cv '.$nombreAspirante;
    $html = ob_get_clean();
    
    use Dompdf\Dompdf;
    use Dompdf\Options;
    ob_start();
    $options = new Options();
    $options->set('chroot', realpath(''));
    $options->set(['chroot' => __DIR__]);
    $dompdf = new Dompdf($options);
    $dompdf->load_html($html);
    $dompdf->render();
    $dompdf->stream($nombrePdf, array('Attachment'=>false));




?>