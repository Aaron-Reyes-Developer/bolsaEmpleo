<?php
$server = "localhost";
$usuario = "root";
$pass = "";
$BD = "bolsadeempleohostinger";

$conn = mysqli_connect($server, $usuario, $pass, $BD);
