<?php

session_start();

//si se intenta ingresar sin iniciar sesion
if ($_SESSION['id_aspirantes'] == null) {
    header('Location: ../../LOGIN/login.php');
    die();
}


include("../../conexion.php");

$query = $_POST['query'];
$categoria_carrera = $_POST['categoria_carrera'];

$pagina = $_POST['pagina'];
$limite = 10;
$desde = ($pagina - 1) * $limite;


$queryConsulta = "SELECT 
usuEm.id_usuario_empresa,
oft.id_oferta_trabajo,
oft.puesto, oft.detalle, 
oft.ubicacion_empleo, 
oft.tipo_lugar_empleo , 
oft.tipo_empleo 
FROM oferta_trabajo  as oft 
LEFT JOIN usuario_empresa as usuEm 
ON usuEm.id_usuario_empresa = oft.fk_id_usuario_empresa 
LEFT JOIN datos_empresa as dt 
ON usuEm.id_usuario_empresa = dt.fk_id_usuario_empresa 
WHERE  oft.estado_oferta = 1 
AND oft.categoria_carrera = '$categoria_carrera'
";


$queryConsulta .= $query;

$queryConsulta .= ' ORDER BY oft.fecha_oferta DESC LIMIT ' . $desde . ',' . $limite;

$consulta = mysqli_query($conn, $queryConsulta);

$datos = [];

while ($recorrerConsulta = mysqli_fetch_assoc($consulta)) {
    $datos[] = $recorrerConsulta;
}


echo json_encode($datos);
