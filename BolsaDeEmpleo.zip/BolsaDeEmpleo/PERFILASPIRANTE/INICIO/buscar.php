<?php
include("../../conexion.php");

session_start();
$mostrar_id = $_SESSION['id_aspirantes'];

//si se intenta ingresar sin iniciar sesion
if ($mostrar_id == null) {
    header('Location: ../../LOGIN/login.php');
    die();
}

// NOTIFICACION (icono campana)
$queryNotificacion = mysqli_query($conn, "call bolsadetrabajobd.notificacion('$mostrar_id');");
$n_r_notificacion = mysqli_num_rows($queryNotificacion);
while (mysqli_next_result($conn)) {;
}

// desaparecer el numero de la notificacion
if (isset($_GET['notifiUpdate'])) {
    $queryActualizarNotificacion = mysqli_query($conn, "UPDATE postula SET estado_noti = '0' WHERE fk_id_usuEstudiantes = '$mostrar_id' AND estado_noti = 1 ");
    header('Location: ./perfilAspirante.php');
}


// consultar los datos del estudiante
$queryCunsultaDatosPadre = mysqli_query($conn, "call datosMainEstudiante('$mostrar_id')");
$recorrerConsultaPadre = mysqli_fetch_array($queryCunsultaDatosPadre);
while (mysqli_next_result($conn)) {;
}



//consultar datos de mis postulaciones
$queryPostulacion = "call consultaOfertaEmpleoEstudiante('$mostrar_id')";
$respuestaPostulacion = mysqli_query($conn, $queryPostulacion);
while (mysqli_next_result($conn)) {;
}


// consulta para la mostrar los nombres de la empresa en el select del formulario 
$queryNombreEmpresa = mysqli_query($conn, "SELECT id_datos_empresa, nombre FROM datos_empresa");
$datosNombreEmpresa = array();
while ($recorrerNombreEmpresa = mysqli_fetch_array($queryNombreEmpresa)) {
    $datosNombreEmpresa[] = $recorrerNombreEmpresa;
}

// si se apreta el boton postularme
if (isset($_POST['Botonpostularme'])) {

    $id_oferta = $_REQUEST['id_oferta'];


    // ingresar oferta en la tabla postula
    $queryPostula = "INSERT INTO postula (fecha_postulacion, fk_id_usuEstudiantes, fk_id_oferta_trabajo) VALUES (current_timestamp(), '$mostrar_id', '$id_oferta')";
    $respuestaPostula = mysqli_query($conn, $queryPostula);

    // si sale bien todo
    if ($respuestaPostula) {

        $_SESSION['postulado'] = true;

?>

        <body>
            <!-- MODAL -->
            <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
            <script src="./modalPostulacionCorrecto.js"></script>

        </body>


<?php
    }
}



// dato de la carrera graduada
$carreraGraduada = $recorrerConsultaPadre['carrera_graduada'];



$limiteConsulta = 5;

if (empty($_GET['pagina'])) {
    $pagina = 1;
} else {
    $pagina = $_GET['pagina'];
}


// operacion
$desde = ($pagina - 1) * $limiteConsulta;



////////////////////////////////////    BUSCAR  //////////////////////////////////

// datos
if (!isset($_REQUEST['buscar'])) {
    $buscar = "";
} else {
    $buscar = htmlspecialchars($_REQUEST['buscar']);
}


if (!isset($_REQUEST['filtrarEstado'])) {
    $filtrarEstado = "";
} else {
    $filtrarEstado = htmlspecialchars($_REQUEST['filtrarEstado']);
}


if (!isset($_REQUEST['filtrarEmpresa'])) {
    $filtrarEmpresa = "";
} else {
    $filtrarEmpresa = htmlspecialchars($_REQUEST['filtrarEmpresa']);
}

if ($buscar == "" && $filtrarEstado == "" && $filtrarEmpresa == "") {
    header("Location: ./inicio.php");
}

// este query trae la oferta de trabajo sin importar el dato que le pase, esta bien estructurado con if anidados en mysql
$queryOfertas = mysqli_query($conn, "call BuscarInicioAspiranteConLimite('$carreraGraduada', '$buscar', '$filtrarEstado', '$filtrarEmpresa', 1,$desde, $limiteConsulta) ");
while (mysqli_next_result($conn)) {;
}

// el mismo query de arriba pero sin limite para la paginacion
$queryTotalOferta = mysqli_query($conn, "call BuscarInicioAspiranteSinLimite('$carreraGraduada', '$buscar', '$filtrarEstado', '$filtrarEmpresa',1) ");
$recorrerTotalOferta = mysqli_fetch_array($queryTotalOferta);
while (mysqli_next_result($conn)) {;
}


// datos para la paginacion
$totalOfertas = $recorrerTotalOferta['totalOferta'];
$total_paginas = ceil($totalOfertas / $limiteConsulta);





//Funcion para limintar una cadena de texto
function limitar_cadena($cadena, $limite, $sufijo)
{

    // Si la longitud es mayor que el límite...
    if (strlen($cadena) > $limite) {
        // Entonces corta la cadena y ponle el sufijo
        return substr($cadena, 0, $limite) . $sufijo;
    }

    // Si no, entonces devuelve la cadena normal
    return $cadena;
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../../imagenes/iconos/iconoAdmin/iconoPaginas.gif">

    <!-- BOOSTRAP -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

    <!-- FUENTE DE FONT GOOGLE -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital@1&display=swap" rel="stylesheet">

    <!-- ANIMACION LIBRERIA -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">


    <!-- ICONOS FAST AWESOME -->
    <script src="https://kit.fontawesome.com/530f126b4a.js" crossorigin="anonymous"></script>


    <link rel="stylesheet" href="estiloInicio.css">
    <title>Inicio</title>
</head>

<body>

    <header class="">
        <nav class="navbar navbar-expand-lg lg-white">

            <div class="container-fluid ">

                <a class="navbar-brand" href="../../index.html">
                    <img src="../../imagenes/logoUnesum.png" alt="">
                </a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>


                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">

                    <ul class="navbar-nav">

                        <li class="nav-item iconoLisa ">
                            <a class="nav-link iconoEnlace" aria-current="page" href="../INICIO/inicio.php"><img src="../../imagenes/Iconos/casa.svg" alt=""></a>
                        </li>


                        <li class="nav-item iconoLisa">
                            <a class="nav-link iconoEnlace" aria-current="page" href="../../ENCONTRETRABAJO/encontreTrabajo.php"><img src="../../imagenes/Iconos/maleta.svg" alt=""></a>
                        </li>

                        <li class="nav-item iconoLisa iconoCampana">

                            <?php

                            if ($n_r_notificacion >= 1) {


                            ?>
                                <div class="dropdown">

                                    <!-- icono campana con la notificacion -->
                                    <a class="iconoEnlace" data-bs-toggle="dropdown" aria-expanded="false">

                                        <img src="../../imagenes/Iconos/campana.svg" alt="">

                                        <div class="bg-danger rounded text-light numero_icono">
                                            <?php echo $n_r_notificacion ?>
                                        </div>
                                    </a>

                                    <ul class="dropdown-menu">

                                        <?php

                                        while ($recorrerNoti = mysqli_fetch_array($queryNotificacion)) {

                                        ?>
                                            <li><a class="dropdown-item notificacionTexto" href="../../DETALLEOFERTA/detalleOferta.php?id_oferta=<?php echo $recorrerNoti['fk_id_oferta_trabajo'] ?>&puesto=<?php echo urlencode($recorrerNoti['puesto']) ?>"><?php echo "Aprobado en: " . "<b>" . $recorrerNoti['puesto'] . "</b>" ?></a></li>

                                        <?php
                                        }
                                        ?>

                                        <hr>
                                        <li><a class="dropdown-item marcarComoLeido" href="?notifiUpdate=ok">Marcar como leido</a></li>
                                        <li><a class="dropdown-item" href="../../VERNOTIFICACIONES/verNotificaciones.php">Ver todas las notifi...</a></li>
                                    </ul>
                                </div>
                            <?php


                            } else {
                            ?>
                                <div class="dropdown">

                                    <!-- icono campana con la notificacion -->
                                    <a class="iconoEnlace" data-bs-toggle="dropdown" aria-expanded="false">

                                        <img src="../../imagenes/Iconos/campana.svg" alt="">
                                    </a>

                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item">Sin Notificaciones 😥</a></li>
                                        <hr>
                                        <li><a class="dropdown-item" href="../VERNOTIFICACIONES/verNotificaciones.php">Ver todas la notificaciones...</a></li>
                                    </ul>
                                </div>



                            <?php
                            }


                            ?>
                            <!-- <a class="nav-link iconoEnlace" aria-current="page" href="#"></a> -->
                        </li>

                        <li class="nav-item iconoLisa">
                            <!-- Mandar un dato al cerrarSesion para que tenga acceso -->
                            <?php $_SESSION['ok'] = "ok" ?>


                            <a class="nav-link iconoEnlace" aria-current="page" href="../../cerrarSesion.php"><img src="../../imagenes/Iconos/salir.svg" alt=""></a>
                        </li>

                        <li class="nav-item lista-avatar-nav">
                            <a class="nav-link enlace-avatar" aria-current="page" href="../perfilAspirante.php"><img src="data:Image/jpg;base64,<?php echo base64_encode($recorrerConsultaPadre['imagen_perfil']) ?>" alt=""></a>
                        </li>



                    </ul>

                </div>


            </div>

        </nav>
    </header>


    <main class="main">

        <!-- MIS POSTULACIONES -->
        <section class="seccionMisPostulaciones">

            <h3><a href="../MISPOSTULACIONES/misPostulaciones.php">Mis postulaciones</a></h3>

            <div class="contenedorMisPostulaciones">

                <?php

                while ($recorrerPostulaciones = mysqli_fetch_array($respuestaPostulacion)) {
                ?>

                    <!-- carta -->
                    <div class="misPostulaciones">

                        <div class="detalles">

                            <h5><?php echo $recorrerPostulaciones['puesto'] ?></h5>
                            <ul>
                                <li><b>Empresa: </b> <?php echo $recorrerPostulaciones['nombre'] ?> </li>
                                <li><b>Tipo: </b> <?php echo $recorrerPostulaciones['tipo_lugar_empleo'] ?> </li>
                                <li><b>Oferta: </b> <?php echo $recorrerPostulaciones['tipo_empleo'] ?></li>
                            </ul>

                        </div>

                        <a href="../../DETALLEOFERTA/detalleOferta.php?id_oferta=<?php echo $recorrerPostulaciones['id_oferta_trabajo'] ?>&puesto=<?php echo urlencode($recorrerPostulaciones['puesto']) ?>">Ver Detalles...</a>
                    </div>

                <?php
                }


                ?>

            </div>

        </section>


        <!--OFERTAS  -->
        <section class="seccionOfertasDeEmpleo">

            <h1>Ofertas de Empleo / Bacantes (<?php echo $totalOfertas ?>)</h1>
            <hr>

            <!-- Se muestra un link cunado el tamaño sea de un celular -->
            <div class="MostraMis">
                <a href="../MISPOSTULACIONES/misPostulaciones.php">Mis postulaciones...</a>
                <a href="../MISPOSTULACIONES/misPostulaciones.php">Mostrar mis ofertas aprobadas...</a>
            </div>


            <!-- FORMULARIO DE BUSQUEDAS -->
            <div>

                <div class="contenedorFormulario">

                    <!-- BUSCAR -->
                    <form action="./buscar.php" method="get" class="formularioBuscar formulario">

                        <!--buscar  -->
                        <div class="mb-3 ">
                            <div class="subContenedorImputs mb-3">
                                <input type="text" class="form-control inputBuscar" name="buscar" id="exampleFormControlInput1" placeholder="Nombre de oferta" value="<?php echo $buscar ?>">

                            </div>
                        </div>

                        <!-- filtar -->
                        <div class="mb-3 subContenedorImputs subContenedorImputFiltrar">

                            <select class="form-select seleccionFiltrar" name="filtrarEstado" aria-label="Default select example">
                                <option selected value="" disabled>Filtrar por Estado</option>
                                <option value="Pasante">Pasante</option>
                                <option value="Puesto de trabajo">Puesto de trabajo</option>
                                <option value="Colaborador de proyecto">Colaborador de proyecto</option>
                            </select>


                        </div>

                        <!-- filtrar por empresa -->
                        <div class="mb-3 subContenedorImputs subContenedorImputFiltrar">

                            <select class="form-select seleccionFiltrar" name="filtrarEmpresa" aria-label="Default select example">
                                <option selected value="" disabled>Filtrar por Empresa</option>

                                <?php
                                foreach ($datosNombreEmpresa as $e) {
                                ?>
                                    <option value="<?php echo $e['nombre'] ?>"><?php echo $e['nombre'] ?></option>
                                <?php
                                }
                                ?>


                            </select>


                        </div>

                        <input type="submit" value="Buscar" class="btn btn-primary botonBuscar">
                    </form>

                </div>

            </div>



            <!-- OFERTAS -->
            <div class="seccionOfertas">

                <?php


                while ($recorrerOfertas = mysqli_fetch_array($queryOfertas)) {


                    // buscar si en la oferta ya se postulo el aspirante para desactivar el boton de "postular"
                    $id_oferta = $recorrerOfertas['id_oferta_trabajo'];
                    $queryBuscarPostulanteEnOferta = "SELECT * FROM postula WHERE fk_id_oferta_trabajo = '$id_oferta' and fk_id_usuEstudiantes = '$mostrar_id' ";
                    $resultadoBuscarPostulanteEnOferta = mysqli_query($conn, $queryBuscarPostulanteEnOferta);
                    $contar_rows_BuscarPostulanteEnOferta = mysqli_num_rows($resultadoBuscarPostulanteEnOferta);


                ?>

                    <!-- carta -->
                    <div class="oferta">

                        <h4><?php echo $recorrerOfertas['puesto'] ?></h4>
                        <p><?php echo limitar_cadena($recorrerOfertas['detalle'], 170, '...') ?></p>

                        <ul class="ul_ofertas">
                            <li><b>Lugar: </b> Manta-Manabi-Ecuador</li>
                            <li><b>Tipo: </b> <?php echo $recorrerOfertas['tipo_lugar_empleo'] ?></li>
                            <li><b>Oferta: </b> <?php echo $recorrerOfertas['tipo_empleo'] ?></li>
                        </ul>

                        <div class="detalles_postular">

                            <!-- id oferta -->
                            <?php $id_oferta = $recorrerOfertas['id_oferta_trabajo']  ?>

                            <a href="../../DETALLEOFERTA/detalleOferta.php?id_oferta=<?php echo $id_oferta ?>&puesto=<?php echo urlencode($recorrerOfertas['puesto']) ?>">Ver detalles...</a>


                            <!-- si ya esta postulado en la oferta desaparece el boton -->
                            <?php
                            if ($contar_rows_BuscarPostulanteEnOferta <= 0) {


                            ?>
                                <form action="./inicio.php?id_oferta=<?php echo $id_oferta ?>" method="post" class="formularioPostular">
                                    <input type="submit" name="Botonpostularme" value="Postularme" class="btn btn-primary Botonpostularme">
                                </form>

                            <?php
                            } else {
                                echo "postulado";
                            }
                            ?>


                        </div>

                    </div>


                <?php
                }
                ?>



            </div>


            <!-- PAGINACION -->
            <div class="contenedorPaginacion">

                <nav aria-label="Page navigation example">
                    <ul class="pagination">

                        <!--la paginacion funciona capturando el dato de paginacion que viene en la url,
                            hacemos un for para mostrar el numero de paginas que hay, se descativa la flecha ('>>') 
                            cunado el limite de pagina sobrepase    
                        -->
                        <?php
                        $i = 0;
                        $limitePaginacion = 7;
                        $limitacion = false;
                        for ($i; $i < $total_paginas; $i++) {

                            // pregunta si 'i' es menor que la limitacion, 
                            //si es verdad entonces entra en la paginacion, 
                            //si no es verdad detiene la paginacion y pone un (..)
                            //para indicar que hay mas paginas

                            if ($i < $limitePaginacion) {
                                $limitacion = true;
                        ?>
                                <li class="page-item <?php if ($pagina == $i + 1) echo 'active' ?>"><a class="page-link" href="?buscar=<?php echo $buscar ?>&filtrarEstado=<?php echo $filtrarEstado ?>&filtrarEmpresa=<?php echo $filtrarEmpresa ?>&pagina=<?php echo $i + 1 ?>"> <?php echo $i + 1 ?> </a> </li>
                            <?php
                            }
                        }

                        // para poner la limitacion de la paginacion (...)
                        if ($limitacion) {
                            ?>
                            <li class="page-item"><a class="page-link disabled" href="">...</a></li>
                        <?php
                        }

                        ?>

                        <!-- boton seguir pagina -->
                        <li>
                            <a class="page-link <?php if ($pagina > $i - 1) echo 'disabled' ?>" href="?buscar=<?php echo $buscar ?>&filtrar=<?php echo $filtrar ?>&pagina=<?php echo $pagina + 1 ?>" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>

                        <?php
                        // validacino si se pone en la url dos paginas mayor a la que se encuentra en la oaginacion
                        if ($pagina - 1 > $total_paginas) {
                            echo "<script> window.location.href = './inicio.php' </script>";
                        }
                        ?>
                    </ul>
                </nav>

            </div>

        </section>

        <!-- APROBADAS -->
        <section class="seccionNoSe">

            <h3>Aprobadas</h3>

            <div class="contenedorMisPostulaciones">

                <?php
                //mostrar las postulaciones aprobadas
                $queryPostulacionesAprobadas = "call postulacionAprobada('$mostrar_id') ";
                $respuestaPostulacionesAprobadas = mysqli_query($conn, $queryPostulacionesAprobadas);

                while ($recorrerPostulacionesAprobadas = mysqli_fetch_array($respuestaPostulacionesAprobadas)) {
                ?>
                    <!-- carta -->
                    <div class="misPostulaciones postulacionAprobada">

                        <div class="detalles">

                            <h5> <?php echo $recorrerPostulacionesAprobadas['puesto'] ?> </h5>
                            <ul>
                                <li><b>Empresa: </b> <?php echo $recorrerPostulacionesAprobadas['nombre'] ?> </li>
                                <li><b>Tipo: </b> <?php echo $recorrerPostulacionesAprobadas['tipo_lugar_empleo'] ?> </li>
                                <li><b>Oferta: </b> <?php echo $recorrerPostulacionesAprobadas['tipo_empleo'] ?> </li>
                            </ul>

                        </div>
                        <a href="../../DETALLEOFERTA/detalleOferta.php?id_oferta=<?php echo $recorrerPostulacionesAprobadas['fk_id_oferta_trabajo'] ?>&puesto=<?php echo urlencode($recorrerPostulacionesAprobadas['puesto']) ?>">Ver Detalles...</a>
                    </div>
                <?php
                }
                ?>




            </div>



            </div>
        </section>


    </main>

    <!-- script boostrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>

    <!-- VALIDAR FORMULARIO VACIOS -->
    <script src="../LOGIN/scriptValidarFormulario.js"></script>



    <!-- JS LIBRERIA ANIMACIONES -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>

    <!-- evitar el reenvio de los formularios -->
    <script src="../../evitarReenvioFormulario.js"></script>
</body>

</html>