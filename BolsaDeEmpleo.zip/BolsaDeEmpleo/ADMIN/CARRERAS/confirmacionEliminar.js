function confirmacion(e){
    if( confirm('¿Estas seguro que quieres eliminarlo?') ) {
        return true;
    }else{
        e.preventDefault();
    }
}