( async () => { 

    //modal
    const {value: accept} = await Swal.fire({
        title: 'Correcto',
        text: "Eliminado Correctamente",
        icon: 'sucsses',
        confirmButtonText: "Regresar" ,
        allowOutsideClick:false
    })
    
    
    if (accept) {
        window.history.back();
    }
})()