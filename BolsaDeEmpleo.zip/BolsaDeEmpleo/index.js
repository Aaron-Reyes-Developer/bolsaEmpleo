Swal.fire({
    title: 'Good job!',
    text: 'Se registro correctamente tu perfil',
    confirmButtonText: 'Ir a Login'
    
})
  
