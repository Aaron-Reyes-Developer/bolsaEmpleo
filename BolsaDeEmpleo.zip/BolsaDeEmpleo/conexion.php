<?php
    $server = "localhost";
    $usuario = "root";
    $pass = "";
    $BD = "bolsadetrabajobd";

    $conn = mysqli_connect($server, $usuario, $pass, $BD);

    
?>