<?php

session_start();

if (isset($_SESSION['id_empresa']) == null || $_SESSION['id_empresa'] == "") {
    header("Location: ../../LOGIN/login.php");
}

include("../../conexion.php");
$id_empresa = $_SESSION['id_empresa'];


//mostrar todos los datos de la empresa
$queryDatosEmpresa = "SELECT * FROM datos_empresa WHERE fk_id_usuario_empresa = '$id_empresa' ";
$respuestaDatosEmpresa = mysqli_query($conn, $queryDatosEmpresa);

$recorrerDatosEmpresa = mysqli_fetch_array($respuestaDatosEmpresa);


// OPERACION PAGINACION
$limiteConsulta = 5;

if (empty($_GET['pagina'])) {
    $pagina = 1;
} else {
    $pagina = $_GET['pagina'];
}

$desde = ($pagina - 1) * $limiteConsulta;




//consulta para saber si existen postulantes en las ofertas de trabajo
$queryPostulantesEnOferta = "call consultaCuantosAspirantesEstanEnUnaOferta('$id_empresa',0,10)";
$respuestaPostulantesEnOferta = mysqli_query($conn, $queryPostulantesEnOferta);
while (mysqli_next_result($conn)) {;
}




/////////////////////   BUSCAR  ////////////////

$buscar = "";
$filtrar = "";
$filtrarEstado = "";
$especializacion = "";

if (isset($_REQUEST['buscar'])) {
    $buscar = htmlspecialchars($_REQUEST['buscar']);
}

if (isset($_REQUEST['filtrar_carrera'])) {
    $filtrar = htmlspecialchars($_REQUEST['filtrar_carrera']);
}

if (isset($_REQUEST['filtrar_estado'])) {
    $filtrarEstado = htmlspecialchars($_REQUEST['filtrar_estado']);
}

if (isset($_REQUEST['especializacion'])) {
    $especializacion = htmlspecialchars($_REQUEST['especializacion']);
}

if ($buscar === "" && $filtrar == "" && $filtrarEstado === "" && $especializacion === "") {
    header('Location: ./inicioEmpresa.php');
}

// muestra todos los aspirantes, no importa que dato le llegue, esta validado en mysql
$queryDatosEstudiantes = mysqli_query($conn, "call BuscarInicioEmpresaConLimite('$buscar', '$filtrar', '$filtrarEstado', '$especializacion', 1, $desde, $limiteConsulta)");
while (mysqli_next_result($conn)) {;
}

// obtienes las filas solo del id aspirante para ser contadas, para la paginacion
$queryDatosEstudiantesSinLimite = mysqli_query($conn, "call BuscarInicioEmpresaSinLimite('$buscar', '$filtrar', '$filtrarEstado', '$especializacion',1)");
while (mysqli_next_result($conn)) {;
}



// datos para la paginacion
$totalEstudiantes = mysqli_num_rows($queryDatosEstudiantesSinLimite);
$total_paginas = ceil($totalEstudiantes / $limiteConsulta);



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../../imagenes/iconos/iconoAdmin/iconoPaginas.gif">

    <!-- BOOSTRAP -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

    <!-- FUENTE DE FONT GOOGLE -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital@1&display=swap" rel="stylesheet">

    <!-- ANIMACION LIBRERIA -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">


    <!-- ICONOS FAST AWESOME -->
    <script src="https://kit.fontawesome.com/530f126b4a.js" crossorigin="anonymous"></script>


    <link rel="stylesheet" href="estiloInicioEmpresa.css">
    <title>Inicio Empresa</title>
</head>

<body>

    <header class="">
        <nav class="navbar navbar-expand-lg lg-white">

            <div class="container-fluid ">

                <a class="navbar-brand" href="../../index.html">
                    <img src="../../imagenes/logoUnesum.png" alt="">
                </a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>


                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">

                    <ul class="navbar-nav">

                        <li class="nav-item iconoLisa ">
                            <a class="nav-link iconoEnlace" aria-current="page" href="./inicioEmpresa.php"><img src="../../imagenes/Iconos/casa.svg" alt=""></a>
                        </li>


                        <li class="nav-item iconoLisa">
                            <a class="nav-link iconoEnlace" aria-current="page" href="#"><img src="../../imagenes/Iconos/maleta.svg" alt=""></a>
                        </li>

                        <li class="nav-item iconoLisa">
                            <a class="nav-link iconoEnlace" aria-current="page" href="#"><img src="../../imagenes/Iconos/campana.svg" alt=""></a>
                        </li>

                        <li class="nav-item iconoLisa">
                            <!-- Mandar un dato al cerrarSesion para que tenga acceso -->
                            <?php $_SESSION['ok'] = "ok" ?>


                            <a class="nav-link iconoEnlace" aria-current="page" href="../../cerrarSesion.php"><img src="../../imagenes/Iconos/salir.svg" alt=""></a>
                        </li>

                        <li class="nav-item lista-avatar-nav">
                            <a class="nav-link enlace-avatar" aria-current="page" href="../perfilEmpresa.php"><img src="data:Image/jpg;base64,<?php echo base64_encode($recorrerDatosEmpresa['imagen_perfil']) ?>" alt=""></a>
                        </li>



                    </ul>

                </div>


            </div>

        </nav>
    </header>

    <main class="main">

        <section class="curriculumDeLosAspirantes">
            <h2>Currilum de los Aspirantes</h2>
            <h5>Total Aspirantes (<?php echo $totalEstudiantes ?>)</h5>
            <hr>


            <!-- formularios -->
            <div class="contenedor_formularios">

                <form action="./buscarEmpresa.php" method="get" class="formulario formularioBuscar">

                    <!-- buscar -->
                    <div class="mb-3 ">
                        <input type="text" name="buscar" class="form-control" id="exampleFormControlInput1" placeholder="Buscar por Apellido">
                    </div>

                    <!-- Filtrar por carrera -->
                    <div class="mb-3 ">


                        <select class="form-select " name="filtrar_carrera" aria-label="Default select example">

                            <option selected value="" disabled>Selecciona una carrera</option>

                            <?php
                            //  CONSULTA CARRERAS
                            $queryCarreras = mysqli_query($conn, "SELECT * FROM carreras");
                            while ($recorrarCarrea = mysqli_fetch_array($queryCarreras)) {
                                $nombreCarrea = $recorrarCarrea['nombre_carrera'];
                            ?>
                                <option value="<?php echo $nombreCarrea ?>"> <?php echo $nombreCarrea ?> </option>
                            <?php
                            }
                            ?>

                        </select>

                    </div>

                    <!-- Filtrar por estado -->
                    <div class="mb-3 ">


                        <select class="form-select " name="filtrar_estado" aria-label="Default select example">
                            <option selected value="" disabled>Selecciona un estado</option>
                            <option value="En busca de empleo">En busca de empleo</option>
                            <option value="Colaborador de proyecto">Colaborador de proyecto</option>
                            <option value="Pasante">Pasante</option>
                        </select>

                    </div>

                    <!-- Filtrar por especializacion -->
                    <div class="mb-3 ">


                        <select class="form-select " name="especializacion" aria-label="Default select example">
                            <option selected value="" disabled>Selecciona una especializacion</option>
                            <?php
                            // mostrar las especialidades que existen
                            $queryEspecialidades = mysqli_query($conn, "SELECT especializacion_curriculum FROM curriculum group by especializacion_curriculum");

                            while ($recorrerEspecialidades = mysqli_fetch_array($queryEspecialidades)) {
                            ?>
                                <option value="<?php echo $recorrerEspecialidades['especializacion_curriculum'] ?>"> <?php echo $recorrerEspecialidades['especializacion_curriculum'] ?> </option>
                            <?php
                            }

                            ?>


                        </select>

                    </div>

                    <input type="submit" value="Buscar" class="btn btn-primary botonGuardar mb-3">

                </form>

            </div>


            <!-- ASPIRANTES -->
            <div class="contenedor_aspirante">

                <?php
                while ($recorrerDatosEstudiantes = mysqli_fetch_array($queryDatosEstudiantes)) {
                ?>

                    <!-- CARTA -->
                    <div class="cartaAspirante">

                        <!-- avatar -->
                        <div class="contenedor_imagen_avatar">
                            <div class="contenedor_avatar">
                                <img src="data:Image/jpg;base64,<?php echo base64_encode($recorrerDatosEstudiantes['imagen_perfil']) ?>" alt="">
                            </div>
                        </div>

                        <!-- datos -->
                        <div class="conetenedorDatos">
                            <h3><?php echo $recorrerDatosEstudiantes['nombres'] ?></h3>
                            <p> <?php echo $recorrerDatosEstudiantes['detalle_curriculum'] ?> </p>

                            <ul>
                                <li> <b>Carrera: </b> <?php echo $recorrerDatosEstudiantes['carrera_graduada'] ?> </li>
                                <li> <b>Especialidad: </b> <?php echo $recorrerDatosEstudiantes['especializacion_curriculum'] ?> </li>
                            </ul>

                        </div>

                        <a href="../../PERFILESPUBLICOS/PERFILASPIRANTE/perfilAspirante.php?id_aspirante=<?php echo $recorrerDatosEstudiantes['id_usuEstudiantes'] ?>">Ver detalles...</a>

                    </div>

                <?php

                }


                ?>

                <!-- PAGINACION -->
                <div class="contenedorPaginacion">

                    <nav aria-label="Page navigation example">
                        <ul class="pagination">

                            <!--la paginacion funciona capturando el dato de paginacion que viene en la url,
                                hacemos un for para mostrar el numero de paginas que hay, se descativa la flecha ('>>') 
                                cunado el limite de pagina sobrepase    
                            -->
                            <?php
                            $i = 0;
                            $limitePaginacion = 7;
                            $limitacion = false;
                            for ($i; $i < $total_paginas; $i++) {

                                // pregunta si 'i' es menor que la limitacion, 
                                //si es verdad entonces entra en la paginacion, 
                                //si no es verdad detiene la paginacion y pone un (..)
                                //para indicar que hay mas paginas

                                if ($i < $limitePaginacion) {
                                    $limitacion = true;
                            ?>
                                    <li class="page-item <?php if ($pagina == $i + 1) echo 'active' ?>">
                                        <a class="page-link" href="?pagina=<?php echo $i + 1 ?>&buscar=<?php echo $buscar ?>&filtrar_carrera=<?php echo $filtrar ?>&filtrar_estado=<?php echo $filtrarEstado ?>&especializacion=<?php echo $especializacion ?>"> <?php echo $i + 1 ?> </a>
                                    </li>
                                <?php
                                }
                            }

                            // para poner la limitacion de la paginacion (...)
                            if ($limitacion) {
                                ?>
                                <li class="page-item"><a class="page-link disabled" href="">...</a></li>
                            <?php
                            }

                            ?>

                            <!-- boton seguir pagina -->
                            <li>
                                <a class="page-link <?php if ($pagina > $i - 1) echo 'disabled' ?>" href="?buscar=<?php echo $buscar ?>&filtrar=<?php echo $filtrar ?>&pagina=<?php echo $pagina + 1 ?>" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>


                        </ul>
                    </nav>

                </div>
            </div>

        </section>


        <section class="Postulantes">
            <h2>Postulantes</h2>
            <hr>

            <div class="contenedorPostulantes">

                <?php

                while ($recorrerPostulantesEnOferta = mysqli_fetch_array($respuestaPostulantesEnOferta)) {
                    $id_oferta = $recorrerPostulantesEnOferta['id_oferta_trabajo'];
                ?>

                    <!-- carta -->
                    <div class="postulante">
                        <h5><?php echo $recorrerPostulantesEnOferta['puesto'] ?></h5>
                        <a href="../../VEROFERTACONASPIRANTES/verOfertasConAspirantes.php?puesto=<?php echo urlencode($recorrerPostulantesEnOferta['puesto']) ?>">Ver aspirantes...</a>
                    </div>
                <?php
                }

                ?>




            </div>
        </section>





    </main>


    <!-- script boostrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>

    <!-- JS LIBRERIA ANIMACIONES -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
</body>

</html>