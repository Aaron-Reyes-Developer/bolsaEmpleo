<?php
session_start();

if (!isset($_SESSION['id_empresa']) || $_SESSION['id_empresa'] == "") {
    header("Location: ../../LOGIN/login.php");
    die();
}

include("../../conexion.php");

//  CONSULTA CARRERAS
$queryCarreras = mysqli_query($conn, "SELECT * FROM carreras");


// CONSULTA PARA MOSTRAR LOS DATOS EN LO INPUTS CUANDO SE QUIERA EDITAR LA OFERTA
if ((isset($_REQUEST['editar']) && isset($_REQUEST['id_oferta']))  && ($_REQUEST['editar'] == "ok" && $_REQUEST['id_oferta'] != "")) {

    $id_oferta = $_REQUEST['id_oferta'];

    // consulta para editar
    $queryOferta = mysqli_query($conn, "SELECT * FROM oferta_trabajo WHERE id_oferta_trabajo = '$id_oferta' ");
    $recorrerOferta = mysqli_fetch_array($queryOferta);
}

// EDITAR LA OFERTA
if (isset($_POST['guardar']) && isset($id_oferta) && ($_REQUEST['editar'] == "ok" && isset($_REQUEST['editar']))) {

    // DATOS
    $nombrePuesto = htmlspecialchars($_POST['nombrePuesto']);
    $precio = htmlspecialchars($_POST['precio']);
    $tipo_empleo = htmlspecialchars($_POST['tipo_empleo']);
    $tipo_lugar = htmlspecialchars($_POST['tipo_lugar']);
    $tipo_carrera = htmlspecialchars($_POST['tipo_carrera']);
    $detalle_empleo = htmlspecialchars($_POST['detalle_empleo']);
    $horario = htmlspecialchars($_POST['horario']);
    $fecha = date("Y-m-d");


    // CONSULTA PARA EDITAR LA OFERTA
    $queryEditarLaOferta = mysqli_query($conn, "UPDATE oferta_trabajo SET `puesto` = '$nombrePuesto', `precio` = '$precio', `tipo_empleo` = '$tipo_empleo', `tipo_lugar_empleo` = '$tipo_lugar', `categoria_carrera` = '$tipo_carrera', `detalle` = '$detalle_empleo', `horario` = '$horario', `fecha_oferta` = '$fecha' WHERE `oferta_trabajo`.`id_oferta_trabajo` = '$id_oferta' ");

    if ($queryEditarLaOferta) {
?>
        <section>

            <!-- MODAL -->
            <script src="../../evitarReenvioFormulario.js"></script>
            <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
            <script src="./modalOferta.js"></script>

        </section>
    <?php
    }
}


// GUARDAR LA OFERTA
if (isset($_POST['guardar']) && !isset($_REQUEST['editar'])) {

    // VALIDAR QUE NINGUN DATO VENGA VACIO
    if (
        ($_POST['nombrePuesto'] == "") ||
        ($_POST['tipo_empleo'] == "") ||
        ($_POST['tipo_lugar'] == "") ||
        ($_POST['tipo_carrera'] == "") ||
        ($_POST['detalle_empleo'] == "") ||
        ($_POST['horario'] == "") ||
        ($_POST['ubicacion_empleo'] == "")


    ) {
        echo "<script> alert('Completa todos los campos') </script>";
        echo "<script> window.location.href = './ingresarOferta.php' </script>";
        die();
    }

    //OBTENER LOS DATOS
    $nombrePuesto = htmlspecialchars($_POST['nombrePuesto']);
    $precio = htmlspecialchars($_POST['precio']);
    $tipo_empleo = htmlspecialchars($_POST['tipo_empleo']);
    $tipo_lugar = htmlspecialchars($_POST['tipo_lugar']);
    $tipo_carrera = htmlspecialchars($_POST['tipo_carrera']);
    $detalle_empleo = htmlspecialchars($_POST['detalle_empleo']);
    $horario = htmlspecialchars($_POST['horario']);
    $ubicacion_empleo = htmlspecialchars($_POST['ubicacion_empleo']);
    $id_empresa = $_SESSION['id_empresa'];


    // INGRESAR LOS DATOS A LA BASE DE DATOS
    $queryIngresar = "INSERT INTO oferta_trabajo (puesto, precio, tipo_empleo, tipo_lugar_empleo, categoria_carrera, ubicacion_empleo ,detalle, horario, fk_id_usuario_empresa) VALUES ('$nombrePuesto', '$precio', '$tipo_empleo', '$tipo_lugar', '$tipo_carrera', '$ubicacion_empleo' ,'$detalle_empleo', '$horario',  '$id_empresa' )";
    $respuesta = mysqli_query($conn, $queryIngresar);


    //////////////////////////// ESTE ES EL CODIGO PARA ENVIAR EL EMAIL ////////////////////////////////////////////////


    // (no se como hacerle para enviar correo masivos, porque en la documentacion de mailer dice que no es recomendable ) 


    // // traer el correo de todos los aspirante dependiendo la carrera
    // $queryCorreosAspirante = mysqli_query($conn, "SELECT usuEs.correo FROM usuario_estudiantes as usuEs LEFT JOIN datos_estudiantes as datosEs ON usuEs.id_usuEstudiantes = datosEs.fk_id_usuEstudiantes WHERE carrera_graduada = '$tipo_carrera' AND usuEs.estado_cuenta = 1  ");
    // while (mysqli_next_result($conn)) {;
    // }


    // // traer el nombre de la empresa
    // $queryDatoEmpresa = mysqli_query($conn, "SELECT datosEm.nombre FROM usuario_empresa as usuEm LEFT JOIN datos_empresa as datosEm ON usuEm.id_usuario_empresa = datosEm.fk_id_usuario_empresa WHERE usuEm.id_usuario_empresa = '$id_empresa'  ");
    // $recorrerDatoEmpresa = mysqli_fetch_array($queryDatoEmpresa);
    // while (mysqli_next_result($conn)) {;
    // }

    // // enviar mensaje por email


    // $para = "reyescarvajala@gmail.com";
    // $titulo = 'Nueva Oferta de empleo';
    // $mensaje = "La empresa: " . $recorrerDatoEmpresa['nombre'] . " creo una nueva oferta" . "\nNombre de la oferta: " . $nombrePuesto . "\nIngresa a www.BolsaDeEmpleoUnesum.com";
    // $miCorreo = 'From: bolsadeempleounesum@gmail.com';


    // if (!mail($para, $titulo, $mensaje, $miCorreo)) {
    //     echo "error" . "<br>";
    // } else {
    //     echo "enviado";
    // }



    //////////////////////////// FIND EL CODIGO ////////////////////////////////////////////////


    // SI TODO ESTA BIEN SE LO MANDA A SU PERFIL
    if ($respuesta) {

    ?>
        <section>

            <!-- MODAL -->
            <script src="../../evitarReenvioFormulario.js"></script>
            <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
            <script src="./modalOferta.js"></script>

        </section>
    <?php
    } else {
        echo mysqli_error($conn);
    }
}

// ELIMINAR OFERTA
if (isset($_POST['eliminar']) && isset($_REQUEST['id_oferta'])) {

    // query para ocultar la oferta
    $id_oferta = $_REQUEST['id_oferta'];
    $queryOcultarOferta = mysqli_query($conn, "UPDATE oferta_trabajo SET estado_oferta = '0' WHERE oferta_trabajo.id_oferta_trabajo = '$id_oferta' ");

    if ($queryOcultarOferta) {
    ?>
        <section>

            <!-- MODAL -->
            <script src="../../evitarReenvioFormulario.js"></script>
            <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
            <script src="./modalEliminado.js"></script>

        </section>
<?php
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../../imagenes/Iconos/iconoAdmin/iconoPaginas.gif">



    <!-- BOOSTRAP -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

    <!-- FUENTE DE FONT GOOGLE -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital@1&display=swap" rel="stylesheet">

    <!-- ANIMACION LIBRERIA -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">


    <!-- ICONOS FAST AWESOME -->
    <script src="https://kit.fontawesome.com/530f126b4a.js" crossorigin="anonymous"></script>


    <link rel="stylesheet" href="estiloOFerta.css">
    <title>Ingresar Oferta</title>
</head>

<body>

    <main class="main">

        <!-- PORTADA -->
        <section class="seccionPortada" data-aos="fade-right">

            <div class="contenedorImagen">

                <img src="../../imagenes/portadaFormularioOferta.svg" alt="">

            </div>

        </section>


        <!-- SECCION FORMULARIO -->
        <section class="seccionFormulario" data-aos="fade-left">

            <form action="" method="post" class="fromulario needs-validation" novalidate>

                <div class="tituloFormulario">
                    <h1>Nueva Oferta</h1>
                    <hr>
                </div>

                <!-- NOMBRE PUESTO -->
                <div class="mb-3">
                    <label for="nombrePuesto" class="form-label">Nombre Puesto*</label>
                    <input type="text" class="form-control input" name="nombrePuesto" list="datalistOptions" id="nombrePuesto" placeholder="" value="<?php if (isset($id_oferta)) echo $recorrerOferta['puesto'] ?>" required>
                </div>


                <!-- PRECIO -->
                <div class="mb-3">
                    <label for="precio" class="form-label">Sueldo Mensual aproximado</label>
                    <input type="number" step="0.01" class="form-control input" name="precio" list="datalistOptions" id="precio" placeholder="No ingresar si el sueldo es privado" value="<?php if (isset($id_oferta)) echo $recorrerOferta['precio'] ?>">
                </div>


                <!-- TIPO DE EMPLEO -->
                <div class="mb-3">
                    <label for="tipo_empleo" class="form-label">Tipo de empleo*</label>

                    <select class="form-select" name="tipo_empleo" aria-label="Default select example" required>
                        <option selected disabled value="">Selecione el tipo de empleo</option>

                        <?php
                        $queryTipoEmpleo = mysqli_query($conn, "SELECT * FROM tipos_oferta ORDER BY id_tipo_oferta DESC");

                        while ($recorrerTipoEmpleo = mysqli_fetch_array($queryTipoEmpleo)) {
                        ?>
                            <option value="<?php echo $recorrerTipoEmpleo['nombre'] ?>"><?php echo $recorrerTipoEmpleo['nombre'] ?></option>
                        <?php
                        }
                        ?>


                        <!-- este es el input que solo aparece cuando se va a editar la oferta -->
                        <?php
                        if (isset($id_oferta)) {
                        ?>
                            <!-- esta opcion solo aparece cuando se va a editar la oferta -->
                            <option selected value="<?php if (isset($id_oferta)) echo $recorrerOferta['tipo_empleo'] ?>"><?php if (isset($id_oferta)) echo $recorrerOferta['tipo_empleo'] ?></option>

                        <?php
                        }
                        ?>

                    </select>
                </div>


                <!-- TIPO DE LUGAR -->
                <div class="mb-3">
                    <label for="tipo_lugar" class="form-label">Tipo de lugar*</label>

                    <select class="form-select" name="tipo_lugar" aria-label="Default select example" required>
                        <option selected disabled value="">Selecione el tipo de lugar</option>

                        <?php

                        if (isset($id_oferta)) {
                        ?>
                            <!-- esta opcion solo aparece cuando se va a editar la oferta -->
                            <option selected value="<?php if (isset($id_oferta)) echo $recorrerOferta['tipo_lugar_empleo'] ?>"><?php if (isset($id_oferta)) echo $recorrerOferta['tipo_lugar_empleo'] ?></option>

                        <?php
                        }


                        // mustra las opciones desde la bd
                        $queryLugarOferta = mysqli_query($conn, "SELECT * FROM tipo_lugar_oferta ORDER BY id_tipo_lugar_oferta DESC");

                        while ($recorrerLugarOferta = mysqli_fetch_array($queryLugarOferta)) {
                        ?>

                            <option value="<?php echo $recorrerLugarOferta['nombre'] ?>"><?php echo $recorrerLugarOferta['nombre'] ?></option>

                        <?php
                        }
                        ?>

                    </select>
                </div>


                <!-- CARRERA DIRIGIDA -->
                <div class="mb-3">

                    <label for="tipo_carrera" class="form-label">Carrera Dirigida*</label>

                    <select class="form-select" name="tipo_carrera" aria-label="Default select example" required>
                        <option selected disabled value="">Selecione el tipo de carrera</option>

                        <?php
                        while ($recorrarCarrea = mysqli_fetch_array($queryCarreras)) {
                            $nombreCarrea = $recorrarCarrea['nombre_carrera'];
                        ?>
                            <option value="<?php echo $nombreCarrea ?>"> <?php echo $nombreCarrea ?> </option>
                        <?php
                        }

                        ?>

                        <?php
                        if (isset($id_oferta)) {
                        ?>
                            <!-- esta opcion solo aparece cuando se va a editar la oferta -->
                            <option selected value="<?php if (isset($id_oferta)) echo $recorrerOferta['categoria_carrera'] ?>"><?php if (isset($id_oferta)) echo $recorrerOferta['categoria_carrera'] ?></option>

                        <?php
                        }

                        ?>

                    </select>

                </div>

                <!-- UBICACION DE EMPLEO -->
                <div class="mb-3">
                    <label for="ubicacion_empleo" class="form-label">Ubicacion del Empleo*</label>
                    <input type="text" class="form-control input" name="ubicacion_empleo" list="datalistOptions" id="ubicacion_empleo" placeholder="ej: Jipijapa" value="<?php if (isset($id_oferta)) echo $recorrerOferta['ubicacion_empleo'] ?>" required>

                </div>

                <!-- DETALLE EMPLEO -->
                <div class="mb-3">
                    <label for="detalle_empleo" class="form-label">Detalle empleo*</label>
                    <textarea class="form-control" name="detalle_empleo" id="detalle_empleo" rows="7" required><?php if (isset($id_oferta)) echo $recorrerOferta['detalle'] ?></textarea>

                    <div class="contenedorFormatoDetalleEmpleo">
                        <span>
                            Salto de linea &lt;br&gt;

                        </span>
                    </div>
                </div>


                <!-- HORARIO -->
                <div class="mb-3">


                    <div class="mb-3">

                        <label for="tipo_lugar" class="form-label">Horario*</label>

                        <select class="form-select" name="horario" aria-label="Default select example" required>
                            <option selected disabled value="">Selecione el horario</option>

                            <option value="Tiempo Completo">Tiempo Completo</option>
                            <option value="Medio Tiempo">Medio Tiempo</option>
                            <option value="Tiempo Parcial">Tiempo Parcial</option>
                            <option value="Sin Horario Definido">Sin Horario Definido</option>
                        </select>
                    </div>


                </div>


                <!-- GUARDADR -->
                <div class="mb-3">
                    <input type="submit" value="Guardar" class="form-control input botonGuardar" name="guardar">
                </div>

                <?php
                if (isset($_REQUEST['editar']) && isset($_REQUEST['id_oferta'])) {
                ?>
                    <!-- ELIMINAR -->
                    <div class="mb-3">
                        <input type="submit" value="Eliminar" class="form-control input botonGuardar botonEliminar" name="eliminar">
                    </div>
                <?php
                }
                ?>

            </form>

        </section>


    </main>



    <!-- script boostrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>

    <!-- JS LIBRERIA ANIMACIONES -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>


    <script>
        // Example starter JavaScript for disabling form submissions if there are invalid fields
        (() => {
            'use strict'

            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            const forms = document.querySelectorAll('.needs-validation')

            // Loop over them and prevent submission
            Array.from(forms).forEach(form => {
                form.addEventListener('submit', event => {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                    }

                    form.classList.add('was-validated')
                }, false)
            })
        })()
    </script>
</body>

</html>